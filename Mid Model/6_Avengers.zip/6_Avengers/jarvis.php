<?php
$avengers[]= "hulk";
$avengers[]="cap";
$avengers[]="thor";
$avengers[]="hawkeye";
$avengers[]="blackwidow";
$q = $_REQUEST["q"];
$hint = "";
if(in_array($q,$avengers)){
    $hint="Name already found";
}
else{
    $hint="Name not found";
}
echo $hint;
?>